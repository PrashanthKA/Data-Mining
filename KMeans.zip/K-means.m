%% AT NT Image 400
X = importdata('ATNTFaceImage400.txt', ',');
n = 400;
m = 644;
k = 40;

answers = X(1, 1:n)';
dataset = X(2:m+1, 1:n)';

predicted_classes = kmeans(dataset, k, 'Replicates', 5);

confusion_matrix = zeros(k, k);

for i = 1:n
    confusion_matrix(answers(i), predicted_classes(i)) = confusion_matrix(answers(i), predicted_classes(i)) + 1;
end

confusion_matrix_for_hung = -confusion_matrix;

[ass, cost] = munkres(confusion_matrix_for_hung);
result_conf_matrix_ATNT_dataset = confusion_matrix(:, ass)
accuracy_ATNT_dataset = trace(result_conf_matrix_ATNT_dataset) / sum(sum(result_conf_matrix_ATNT_dataset))

