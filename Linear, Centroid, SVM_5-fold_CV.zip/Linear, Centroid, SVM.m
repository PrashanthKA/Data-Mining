% Write simple classifiers with KNN, Linear, Centroid, SVM 
% through 5 fold cross validation
clc, clear all, close all

%% loading data file
fid = fopen('ATNTFaceImage400.txt');
ATNTFaceImage400 = [];
while ~feof(fid)
    one_row = textscan(fid, '%d', 400, 'delimiter', ',');
    ATNTFaceImage400 = [ATNTFaceImage400; one_row{1}'];
end
fclose(fid);
ATNTFaceImage400 = ATNTFaceImage400';
Face_Group = ATNTFaceImage400(:, 1);
Face_Data = ATNTFaceImage400(:, 2 : end);


%% Accuracy for each fold and average accuracy
CVO = cvpartition(Face_Group, 'k', 5);
err_Linear = zeros(CVO.NumTestSets, 1);

for i = 1 : CVO.NumTestSets
    trIdx = CVO.training(i);
    teIdx = CVO.test(i);
    
    % Linear classifier
    ytest_Linear = Linear_classify(Face_Data(teIdx, :), Face_Data(trIdx, :), Face_Group(trIdx,:));
    err_Linear(i) = sum(~(ytest_Linear == Face_Group(teIdx)));
    
end

CVO = cvpartition(Face_Group, 'k', 5);
err_KNN = zeros(CVO.NumTestSets, 1);

for i = 1 : CVO.NumTestSets
    trIdx = CVO.training(i);
    teIdx = CVO.test(i);
    
    % KNN classifier
    ytest_KNN = knnclassify(Face_Data(teIdx, :), Face_Data(trIdx, :), ...
                            Face_Group(trIdx,:));
    err_KNN(i) = sum(~(ytest_KNN == Face_Group(teIdx)));
%    [c,cm,ind,per] = confusion(ytest_KNN, Face_Group(teIdx));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

CVO = cvpartition(Face_Group, 'k', 5);
err_SVM = zeros(CVO.NumTestSets, 1);

for i = 1 : CVO.NumTestSets
    trIdx = CVO.training(i);
    teIdx = CVO.test(i);
    
    % SVM classifier
    ytest_SVM = Svm_classify(Face_Data(teIdx, :), Face_Data(trIdx, :), Face_Group(trIdx, :));
    err_SVM(i) = sum(~(ytest_SVM == Face_Group(teIdx)));   
end

CVO = cvpartition(Face_Group, 'k', 5);
err_Centroid = zeros(CVO.NumTestSets, 1);

for i = 1 : CVO.NumTestSets
    trIdx = CVO.training(i);
    teIdx = CVO.test(i);
    
    % SVM classifier
    ytest_SVM = Centroid_classify(Face_Data(teIdx, :), Face_Data(trIdx, :), Face_Group(trIdx, :));
    err_Centroid(i) = sum(~(ytest_SVM == Face_Group(teIdx)));   
end
    
    
% Linear Classifier Accuracy
cvErr_Linear = sum(err_Linear) / sum(CVO.TestSize)
accuracy_Linear=(1-cvErr_Linear)*100

% KNN Classifier Accuracy
%cvErr_KNN = sum(err_KNN) / sum(CVO.TestSize)
%accuracy_KNN=(1-cvErr_KNN)*100


% Centroid Classifier Accuracy
%cvErr_Centroid = sum(err_Centroid) / sum(CVO.TestSize);

% SVM Classifier Accuracy
cvErr_SVM = sum(err_SVM) / sum(CVO.TestSize)
accuracy_SVM=(1-cvErr_SVM)*100

% Centroid Classifier Accuracy
cvErr_Centroid = sum(err_Centroid) / sum(CVO.TestSize)
accuracy_Centroid=(1-cvErr_Centroid)*100


%average_Err = (cvErr_Linear + cvErr_KNN + cvErr_SVM+ cvErr_Centroid)/4
%accuracy_average=(1-average_Err)*100

% output
%[c,cm,ind,per] = confusion(target, output)
